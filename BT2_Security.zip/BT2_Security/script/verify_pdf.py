from OpenSSL import crypto
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
import os, re, datetime

# === CẤU HÌNH ĐƯỜNG DẪN ===
signed_pdf = r"D:\BT2_Security\pdf\signed.pdf"
cert_file = r"D:\BT2_Security\keys\signer_cert.pem"
log_file = r"D:\BT2_Security\script\verify_result.txt"

# === HÀM GHI LOG ===
def log_write(text):
    with open(log_file, "a", encoding="utf-8") as log:
        log.write(text + "\n")
    print(text)

# === KHỞI TẠO FILE LOG ===
with open(log_file, "w", encoding="utf-8") as f:
    f.write("=== KIỂM TRA XÁC THỰC CHỮ KÝ PDF ===\n")
    f.write(f"Thời gian kiểm thử: {datetime.datetime.now()}\n")
    f.write(f"File kiểm tra: {os.path.abspath(signed_pdf)}\n")
    f.write("====================================\n")

# === KIỂM TRA FILE TỒN TẠI ===
for fpath in [signed_pdf, cert_file]:
    if not os.path.exists(fpath):
        log_write(f"⚠️ Thiếu file {fpath}")
        raise FileNotFoundError(f"Thiếu file {fpath}")

# === BẮT ĐẦU KIỂM TRA ===
try:
    # Đọc nội dung PDF đã ký
    with open(signed_pdf, "rb") as f:
        data = f.read()

    # Tìm vùng chữ ký trong PDF
    byte_range_pattern = re.compile(rb"/ByteRange\s*\[(\d+) (\d+) (\d+) (\d+)\]")
    match = byte_range_pattern.search(data)
    if not match:
        raise ValueError("Không tìm thấy /ByteRange trong file PDF.")

    byte_range = [int(x) for x in match.groups()]
    log_write(f"🔍 /ByteRange: {byte_range}")

    # Trích xuất phần dữ liệu thực tế được ký (trừ vùng Contents)
    parts = []
    for i in range(0, len(byte_range), 2):
        start, length = byte_range[i], byte_range[i+1]
        parts.append(data[start:start+length])
    signed_data = b"".join(parts)

    # Tìm vùng /Contents (dữ liệu chữ ký PKCS#7)
    contents_pattern = re.compile(rb"/Contents\s*<([0-9A-Fa-f]+)>")
    contents_match = contents_pattern.search(data)
    if not contents_match:
        raise ValueError("Không tìm thấy vùng /Contents trong file PDF.")
    signature_hex = contents_match.group(1)
    signature = bytes.fromhex(signature_hex.decode("utf-8"))

    # Tính hash SHA-256 trên ByteRange
    digest = hashes.Hash(hashes.SHA256())
    digest.update(signed_data)
    pdf_hash = digest.finalize()
    log_write(f"✅ SHA256(ByteRange) = {pdf_hash.hex()[:64]}...")

    # Đọc chứng chỉ người ký
    with open(cert_file, "rb") as f:
        cert_data = f.read()
        cert = crypto.load_certificate(crypto.FILETYPE_PEM, cert_data)

    subject = cert.get_subject()
    issuer = cert.get_issuer()
    cert_sha1 = cert.digest("sha1").decode()
    cert_sha256 = cert.digest("sha256").decode()

    log_write(f"👤 Người ký: {getattr(subject, 'CN', 'N/A')} ({getattr(subject, 'O', 'N/A')})")
    log_write(f"🏢 Nhà phát hành: {getattr(issuer, 'CN', 'N/A')}")

    # Xác thực chữ ký
    public_key = cert.get_pubkey().to_cryptography_key()
    public_key.verify(
        signature,
        pdf_hash,
        padding.PKCS1v15(),
        hashes.SHA256()
    )

    # Nếu không lỗi → chữ ký hợp lệ
    log_write("✅ Kết quả: CHỮ KÝ HỢP LỆ")
    log_write("The signature is cryptographically sound.")
    log_write("The digest algorithm used was 'sha256'.")
    log_write("The signature mechanism used was 'sha256_rsa'.")

    now_vn = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S+07:00")
    log_write(f"🕒 Thời gian ký (VN): {now_vn}")
    log_write("✅ File chưa bị chỉnh sửa kể từ khi ký.")
    log_write("====================================")
    log_write("✅ Chữ ký HỢP LỆ và tài liệu NGUYÊN VẸN.")

except Exception as e:
    log_write("❌ CHỮ KÝ KHÔNG HỢP LỆ HOẶC FILE BỊ SỬA!")
    log_write(f"Lỗi chi tiết: {str(e)}")

log_write("=== KẾT THÚC KIỂM TRA ===")
